﻿using PaltrackInvoice.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaltrackInvoice.Interface
{
    public interface IInvoiceRepo
    {
        Invoice AddInvoice(Invoice invoice);
        List<Invoice> GetInvoices();
        void UpdateInvoice(Invoice invoice);
        void DeleteInvoice(int Id);
        Invoice GetInvoice(int Id);
    }
}
