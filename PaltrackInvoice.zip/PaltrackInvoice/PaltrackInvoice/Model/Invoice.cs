﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PaltrackInvoice.Model
{
    public class Invoice
    {
        [Key]
        public int Id { get; set; }
        [Display(Name ="Date")]
        public DateTime? Date { get; set; }
        [Display(Name= "Invoice No")]
        public string InvoiceNo { get; set; }
        public string Sku { get; set; }
        [Display(Name ="Description")]
        public string Descriptiond { get; set; }
        public int Qty { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }
        public int test { get; set; }
    }
}
