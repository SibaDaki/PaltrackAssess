﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using PaltrackInvoice.Interface;
using PaltrackInvoice.Model;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;


namespace PaltrackInvoice.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InvoiceController : Controller
    {

      
        private readonly IInvoiceRepo _invoice;
      
        private IHostEnvironment _hostEnvironment;

       
        public InvoiceController(IInvoiceRepo invoice, IHostEnvironment hostEnvironment)
        {
            _invoice = invoice;
            _hostEnvironment = hostEnvironment;


        }
        [HttpGet]
       
        public ActionResult<List<Invoice>> GetInvoices()
        {
            var invoices =  _invoice.GetInvoices();
            return View(invoices);
        }
        //public ActionResult ExpExcl()
        //{
        //    List<Invoice> person = new List<Invoice>();
           
        //    var grid = new GridView();
        //    grid.DataSource = person;
        //    grid.DataBind();

        //    Response.ClearContent();
        //    Response.AddHeader("content-disposition", "attachement; filename=data.xls");
        //    Response.ContentType = "application/excel";
        //    StringWriter sw = new StringWriter();
        //    HtmlTextWriter htw = new HtmlTextWriter(sw);
        //    grid.RenderControl(htw);
        //    Response.Output.Write(sw.ToString());
        //    Response.Flush();
        //    Response.End();
        //    return View();
        //}
        public ActionResult Export()
        {
           var dataList =  _invoice.GetInvoices();

            //column Header name
            var columnsHeader = new List<string>{
                "Date",
                "Invoice No",
                "SKU",
                "Desciption",
                "QTY",
                "Amount"
            };
            var filecontent =  Export(dataList, columnsHeader, "Invoices");
            return File(filecontent, "application/ms-excel", "invoices.xlsx"); ;
        }

       

        private byte[] Export(List<Invoice> dataList, List<string> columnsHeader, string heading)
        {
            byte[] result =  null;

            using (ExcelPackage package = new ExcelPackage())
            {
               
                var worksheet = package.Workbook.Worksheets.Add(heading);
                using (var cells = worksheet.Cells[1, 1, 1, 5])
                {
                    cells.Style.Font.Bold = true;
                    cells.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    
                }
               
                for (int i = 0; i < dataList.Count; i++)
                {
                    worksheet.Cells[1, i + 1].Value = dataList[i];
                }

               
                result =  package.GetAsByteArray();
            }

            return  result;
        }

      public async Task<IActionResult> ExportE()
        {
            string sWebRootFolder = _hostEnvironment.ContentRootPath;

              
            string sFileName = @"Invoice.xlsx";       
            string URL = string.Format("{0}://{1}/{2}", Request.Scheme,Request.Host, sFileName);    
            FileInfo file = new FileInfo(Path.Combine(sWebRootFolder,sFileName));       
            var memory = new MemoryStream();
            using (var fs = new FileStream(Path.Combine(sWebRootFolder,sFileName), FileMode.Create, FileAccess.Write))
            {
                IWorkbook workbook;
                workbook = new XSSFWorkbook();
                ISheet excelSheet = workbook.CreateSheet("Invoice");
                IRow row = excelSheet.CreateRow(0);

                row.CreateCell(0).SetCellValue("Date");
                row.CreateCell(1).SetCellValue("Invoice No");
                row.CreateCell(2).SetCellValue("SKU");
                row.CreateCell(3).SetCellValue("Description");
                row.CreateCell(4).SetCellValue("QTY");
                row.CreateCell(4).SetCellValue("Amount");

                workbook.Write(fs);
            }

            using (var stream = new FileStream(Path.Combine(sWebRootFolder,sFileName), FileMode.Open))   
            {
                await stream.CopyToAsync(memory); 
            }           
            memory.Position = 0;
            return File(memory, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", sFileName);
          
        }
    }
       
 }
   



