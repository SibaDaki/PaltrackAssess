﻿using Microsoft.EntityFrameworkCore;
using PaltrackInvoice.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaltrackInvoice.Data
{
    public class InvoiceDbContext : DbContext
    {
        public InvoiceDbContext(DbContextOptions<InvoiceDbContext> options) :
            base(options)
        {

        }
        public DbSet<Invoice> Invoices { get; set; }
    }
}
