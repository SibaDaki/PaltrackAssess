﻿using Microsoft.EntityFrameworkCore;
using PaltrackInvoice.Interface;
using PaltrackInvoice.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PaltrackInvoice.Data
{
    public class InvoiceRepoImpl : IInvoiceRepo
    {

        private readonly InvoiceDbContext _context;
        public InvoiceRepoImpl(InvoiceDbContext context)
        {
            _context = context;
        }

        public List<Invoice> GetInvoices()
        {
            return  _context.Invoices.ToList();
        }
        public Invoice AddInvoice(Invoice invoice)
        {
            _context.Invoices.Add(invoice);
            _context.SaveChanges();
            return invoice;
        }

        public void DeleteInvoice(int Id)
        {
            var invoice = _context.Invoices.FirstOrDefault(x => x.Id == Id);
            if (invoice != null)
            {
                _context.Remove(invoice);
                _context.SaveChanges();
            }
        }

        public Invoice GetInvoice(int Id)
        {
            return _context.Invoices.FirstOrDefault(x => x.Id == Id);
        }

       

        public void UpdateInvoice(Invoice invoice)
        {
            throw new NotImplementedException();
        }

        
    }
}
